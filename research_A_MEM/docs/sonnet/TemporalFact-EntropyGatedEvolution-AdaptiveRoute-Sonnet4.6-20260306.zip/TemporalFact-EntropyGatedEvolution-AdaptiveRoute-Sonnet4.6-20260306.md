# Agent Memory 研究课题生成报告

**生成时间**: 2026-03-06 15:30:00
**生成模型**: Claude Sonnet 4.6 (claude-sonnet-4-6)
**研究领域**: Agent Memory（智能体记忆机制）
**目标期刊/会议**: CCF B类 / CCF C类（以 C 类为保底目标）

---

## 执行过程记录

### 第 0 步：问题诊断——被反复提及但未解决的技术瓶颈

扫描 with_github.md 和 without_github.md 后，锁定以下四个高度确立的技术瓶颈：

| 瓶颈编号 | 问题描述 | 支撑文献（来源） |
|---------|---------|----------------|
| P1 | **选择性遗忘失效**：所有方法在事实更新类多跳任务上准确率 ≤7%，系统无法推断"哪条旧事实应被新信息覆盖" | MemoryAgentBench（with_github），LongMemEval评测（with_github） |
| P2 | **记忆演化稳定性缺失**：LLM驱动的无约束记忆演化可能导致语义漂移、表示污染，缺乏任何稳定性保证机制 | A-MEM（with_github，原文承认） |
| P3 | **单一检索策略的结构性天花板**：RAG 在长程理解任务上严重落后，长上下文在精确检索上低效，已被基准定量证明，无系统实现自适应混合 | MemoryAgentBench（with_github），MEMENTO（with_github） |
| P4 | **语义相似不等于可迁移**：高余弦相似度但结构差异大的经验导致"误导性检索"，现有方法无结构级别的预过滤机制 | ChemAgent（with_github，原文承认），AGENT KB（with_github，领域知识转移不对称） |

### 第 0.5 步：代码主干前置选择

**候选 with_github 论文（仅列 Agent Memory 相关）**

| 论文 | 记忆数据结构 | 检索机制 | 遗忘策略 | 模块化程度（是否支持模块级修改） |
|-----|-----------|---------|---------|-------------------------------|
| EverMemOS | MemCell(Episode+AtomicFacts+Foresight+Metadata) + MemScene(语义聚类) | Dense+BM25 RRF融合 + LLM验证器 + 查询重写 | 前瞻时间边界过滤（有效区间[t_start,t_end]） | **高**：三阶段完全解耦（痕迹形成/语义巩固/重构回忆） |
| A-MEM | 原子笔记{content, timestamp, keywords, tags, context, embedding, links} | 余弦相似度 top-k | **无显式遗忘** | **高**：笔记构建/链接生成/记忆演化三个LLM调用独立 |
| AGENT KB | 结构化经验 E=<π任务嵌入, γ奖励信号, S动作推理序列, C跨框架元数据> | BM25+语义嵌入混合（α可调） | 效用分数驱逐 u_j←u_j+η(r_j−u_j) | **高**：两阶段Reason-Retrieve-Refine循环 + 分歧门独立 |
| ChemAgent | 规划记忆M_p + 执行记忆M_e(子任务+解法) + 知识记忆M_k | 余弦相似度阈值θ过滤 | 置信度<阈值则丢弃 | **中**：评估精炼模块相对独立 |
| EvolveR | 战略原则集E（自然语言描述） | 嵌入相似度检索top-k + 两阶段语义匹配 | 效用分数s(p)=(c_succ+1)/(c_use+2) 修剪 | **高**：离线提炼/在线检索/策略进化三阶段分离 |

**确定主干**：
- **Topic 1 / Topic 3 主干**：EverMemOS（MemCell结构 + 三阶段生命周期架构最适合扩展时间语义和自适应路由）
- **Topic 2 主干**：A-MEM（记忆演化模块独立，entropy门控只需修改一处函数）
- **Topic 4 主干**：AGENT KB（混合检索管道最适合插入结构级预过滤层）

---

## 课题一

### 🏷️ 课题名称

**FactValidity-Aware Memory Consolidation: Temporal Fact Conflict Resolution for Selective Forgetting in Conversational Memory Agents**

（时序事实有效性感知的记忆巩固：面向对话记忆智能体的选择性遗忘提升）

---

### 🔍 问题背景与研究动机（核心逻辑）

**① 当前存在什么明确缺陷？**

MemoryAgentBench（Evaluating Memory in LLM Agents via Incremental Multi-Turn Interactions，with_github）在系统性评测中发现：在**选择性遗忘（Selective Forgetting, SF）**能力维度上，所有评测的记忆方法准确率均 ≤7%（多跳事实整合任务 FactConsolidation-MH），接近完全失效。论文明确指出：

> "在需要多跳推理的选择性遗忘任务上，所有方法近乎崩溃（准确率≤7%），这表明当前记忆机制在处理长序列中相互矛盾信息的逻辑覆盖与推理时存在根本性缺陷。"

典型失败场景：用户在对话第3轮提到"我在北京工作"，第47轮提到"我已经搬到上海了"。当第90轮问"我住在哪里"时，系统应表现"上海"。但现有系统要么同时召回两条矛盾记忆，要么根据相似度随机选一条，无法推断"后者在时序上使前者失效"。

此外，EverMemOS（with_github）虽在 LongMemEval 的知识更新类任务上改善了20.6%，但对于需要**跨多轮、多跳推理**的事实更新链，其 Foresight 机制只覆盖"已知过期"的临时状态，不能处理隐式事实覆盖关系。

**② 现有方法为什么无法解决？**

EverMemOS 的 MemCell 中 Foresight 确实有时间有效区间 [t_start, t_end]，但这依赖 LLM 在写入时**主动推断**时间边界，对于隐式的、需多跳推理才能判断的过期关系（如"加入新公司"隐含"离开旧公司"）无法捕获。Atomic Facts 字段是纯事实存储，没有任何"被哪条新事实覆盖"的指针结构。

其结构性盲区在于：**时间有效性是事实级别的属性，而非固定的时间窗口属性**——一个事实的失效不是由时间过期决定的，而是由另一个具有语义对立关系且时序更晚的事实决定的。

**③ 融合方案如何精准弥补该缺口？**

**问题** → 所有记忆系统在 SF 任务上失效，根因是 Atomic Facts 无时序对立检测
↓
**现有方案缺口** → EverMemOS 的 MemCell 有 Atomic Facts 结构，但无事实级时间有效性追踪；AriGraph（without_github）有冲突检测机制但针对动态环境实体关系而非对话事实
↓
**本方案** → 在 EverMemOS 的 Stage 2（语义巩固）中引入**事实级时序对立检测算法**：当新 MemCell 的 Atomic Facts 与已有 MemScene 中的 Atomic Facts 存在语义对立关系时，触发轻量级 LLM 调用判断"时间更晚的事实是否语义上覆盖时间更早的事实"，并标记旧事实的"有效性状态"为 SUPERSEDED

---

### 🎯 切入点与 CCF C 类潜力

**适合单兵作战的理由**：
- 代码基座明确：EverMemOS 有 GitHub 仓库，Stage 2 的语义聚类模块是独立函数，修改点集中
- 实验基准现成：MemoryAgentBench（with_github）提供标准化评测协议，LoCoMo 和 LongMemEval 数据集公开
- 无模型训练：全部为 API 调用（DeepSeek/GPT-4o-mini）+ 嵌入计算，3060Ti 胜任

**CCF C 类潜力**：
- 问题定义清晰：量化的失败（≤7%）提供极强的 motivation
- 贡献聚焦：在成熟系统上添加一个有明确理论动机的子模块，创新粒度适合 C 类
- 实验对比直接：修改前后在相同基准上的 SF 任务性能提升，结论清晰
- 应用价值：对话系统的知识更新是工业界真实需求

---

### ⚙️ 核心方法/融合机制设计

#### 整体架构

在 EverMemOS 的 **Stage 2（语义巩固）**中，于 MemCell→MemScene 聚类之前插入一个**事实级时序对立检测层（Fact-Level Temporal Validity Resolver, FTVR）**。

#### 数据结构扩展

原 EverMemOS MemCell 的 Atomic Facts 字段：
```
MemCell.F = [fact_1, fact_2, ..., fact_n]  # 纯文本列表
```

扩展后：
```
MemCell.F = [
  {
    "text": "我在北京工作",
    "timestamp": "2023-01-15T10:30:00",
    "validity": "ACTIVE",          # ACTIVE | SUPERSEDED | PENDING_CHECK
    "superseded_by": null,         # 指向覆盖此事实的 MemCell ID
    "conflict_fingerprint": [...]  # 此事实的"对立语义空间"嵌入向量
  },
  ...
]
```

`conflict_fingerprint` 是通过对事实进行**否定式扩展**后的嵌入：对 "我在北京工作" 生成 "工作地点不在北京" 等对立表述，取其平均嵌入向量。这借鉴了 AriGraph 的"冲突检测"思想，但对象从知识图谱三元组改为对话原子事实。

#### FTVR 算法（伪代码）

```python
def fact_temporal_validity_resolve(new_memcell, memscene_pool, embed_model, llm):
    for new_fact in new_memcell.atomic_facts:
        # Step 1: 用 conflict_fingerprint 在历史 MemScene 中快速召回候选冲突事实
        candidates = vector_search(
            query_vec=new_fact.conflict_fingerprint,
            pool=memscene_pool.all_facts,
            top_k=10,
            threshold=0.75  # 只有高对立语义相似度才进入下一步
        )

        if not candidates:
            continue

        # Step 2: 时序前置过滤（只有旧事实才可能被覆盖）
        older_candidates = [f for f in candidates
                           if f.timestamp < new_fact.timestamp]

        if not older_candidates:
            continue

        # Step 3: 轻量级 LLM 判断（仅在候选存在时才触发，降低调用频率）
        for old_fact in older_candidates[:3]:  # 最多判断3个，控制成本
            prompt = f"""Given two facts about the same person/entity:
OLD FACT (recorded {old_fact.timestamp}): {old_fact.text}
NEW FACT (recorded {new_fact.timestamp}): {new_fact.text}

Does the NEW FACT logically supersede (make obsolete) the OLD FACT?
Answer with YES or NO only."""

            decision = llm.call(prompt)  # 单次API调用，约50 tokens

            if decision == "YES":
                old_fact.validity = "SUPERSEDED"
                old_fact.superseded_by = new_memcell.id
                # 触发 MemScene 更新：降低已标记事实在检索中的权重
                update_memscene_weights(old_fact, weight=0.1)
```

#### 检索时的有效性感知

在 EverMemOS Stage 3（重构回忆）的 Atomic Facts 过滤步骤中，添加：
```python
# 原代码：直接返回所有 fact
relevant_facts = filter_by_relevance(facts, query)

# 修改后：过滤掉已失效事实
relevant_facts = [f for f in filter_by_relevance(facts, query)
                  if f.validity != "SUPERSEDED"]
```

#### 来自 H²R（without_github）的理论补强

H²R 指出"静态记忆在动态环境中失效"的根因是**记忆缺乏更新-合并-删除机制**。本方案直接实现了 Atomic Facts 层级的"更新/标记"机制，是 H²R 提出的四种知识操作（Add/Update/Delete/Combine）中"Update"的实例化。

---

### 🧪 实验方案（算力受限 + GitHub 优先）

**实验代码起点**：EverMemOS GitHub 仓库
**具体修改点**：
1. `memcell.py`：扩展 AtomicFact 数据类，添加 validity/superseded_by/conflict_fingerprint 字段
2. `consolidation.py`（Stage 2）：在聚类函数调用前插入 FTVR 算法
3. `recall.py`（Stage 3）：在事实过滤函数中添加 validity 状态检查

**评测环境**：
- DeepSeek-V3 API（主要 LLM，低成本）
- all-MiniLM-L6-v2（本地嵌入，3060Ti 轻松运行）
- Chroma 或 FAISS（向量存储）

**数据集**：
- MemoryAgentBench 的 FactConsolidation 任务集（SF 维度，现有方法 ≤7%）
- LongMemEval 的 Knowledge Update 子集（EverMemOS 基线 89.74%，看是否进一步提升）
- LoCoMo 数据集（知识更新类问题）

**核心评测指标**：
- SF 准确率（主要目标，从 ≤7% 提升）
- LongMemEval 知识更新类准确率
- API 调用次数（与 baseline EverMemOS 对比，控制成本增量）
- 误判率（原本有效的事实被错误标记为 SUPERSEDED 的比例）

**消融实验**：
1. EverMemOS-base（无修改）
2. EverMemOS + FTVR（无 LLM 判断，只用 conflict_fingerprint 阈值）
3. EverMemOS + FTVR（完整方案）

---

### 📚 严格文献溯源与融合逻辑

| 论文 | 来源库 | 融合角色 |
|-----|-------|---------|
| **EverMemOS**（Evaluating Memory...） | **with_github** | **代码基础 + 系统架构主干**：MemCell 数据结构、三阶段生命周期、Stage 2 聚类代码为修改起点 |
| **Evaluating Memory in LLM Agents / MemoryAgentBench** | **with_github** | **创新问题发现**：定量证明 SF 维度全面失效（≤7%），为研究提供清晰动机 |
| **AriGraph**（without_github 版本） | **without_github** | **局部机制启发**：冲突检测思路（检测并删除过时边）启发了 conflict_fingerprint 设计 |
| **H²R**（without_github） | **without_github** | **理论补强**：四种知识操作框架（Add/Update/Delete/Combine）为本方案提供理论依据 |

> 注：上述 2-4 篇为支撑 Method 的核心融合来源；最终论文 Related Work 需另行覆盖 15-20 篇领域文献（包括 Mem0、MemGPT、Zep、A-MEM、ReadAgent 等）。

---

### 🚀 第一步行动指南

1. **立即精读**：
   - EverMemOS 原论文的 Section 3.2（MemCell 结构）和 Section 3.3（Stage 2 语义巩固算法）
   - MemoryAgentBench 的 Section 4.3（SF 任务定义）和 Table 4（SF 结果数据）

2. **优先跑通**：
   - Clone EverMemOS GitHub 仓库
   - 运行 `examples/locomo_eval.py` 或等价的评测脚本，复现 baseline 数据
   - 找到 Stage 2 对应的聚类函数定位，确认可以插入 FTVR 钩子

3. **第一个实验**：在 LongMemEval 的 Knowledge Update 10 条样本上手动验证 conflict_fingerprint 能否正确召回候选对立事实（precision@5 测试）

---
---

## 课题二

### 🏷️ 课题名称

**Entropy-Gated Memory Evolution: Semantic Stability Control for Agentic Memory Systems**

（熵门控记忆演化：智能体记忆系统的语义稳定性控制机制）

---

### 🔍 问题背景与研究动机（核心逻辑）

**① 当前存在什么明确缺陷？**

A-MEM（Agentic Memory for LLM Agents，with_github）在其局限性章节明确承认：

> "演化收敛性与稳定性风险：记忆的持续、LLM驱动的演化缺乏理论保证。在极端场景下（如大量冲突或低质量新记忆涌入），可能导致**记忆表示漂移、语义失真或链接网络陷入混乱**，破坏长期一致性。"

A-MEM 的记忆演化（Memory Evolution）机制：每当新记忆 m_n 到来，对最近邻候选集中的每个旧记忆 m_j 调用 LLM 更新其上下文描述、关键词和标签。这是**无条件触发**的——每条新记忆都会尝试演化最多 10 条旧记忆，每次演化都是一次 LLM 调用，既无稳定性检验也无质量控制。

在长期运行（数百轮对话，数千条记忆）中，持续的 LLM 驱动演化会导致：
- 早期的清晰记忆被后期无关的上下文污染（语义漂移）
- 演化链式传播：A 更新了 B，B 更新了 C，最终 C 与原始事实无关
- 写入延迟随记忆库线性增长（A-MEM 原文也承认这一点）

**② 现有方法为什么无法解决？**

A-MEM 在设计上将"所有记忆都可以演化"作为核心原则，并无区分"稳定的事实性记忆"与"需要持续更新的关系性记忆"的机制。当前实现中，记忆演化全部依赖 LLM 判断（提示模板 P_s3），没有任何基于客观度量的触发条件。

DAM-LLM（Dynamic Affective Memory Management，without_github）提出了**信息熵作为记忆健康度的统一度量**，但其熵计算是针对情感置信度分布的，不直接适用于 A-MEM 的通用记忆场景。

两者的结构性盲区不同：A-MEM 有良好的代码架构但无质量控制；DAM-LLM 有优秀的熵驱动质量控制理论但无通用化记忆框架。正是这种互补性提供了融合空间。

**③ 融合方案如何精准弥补该缺口？**

**问题** → A-MEM 演化无约束，长期运行导致语义漂移
↓
**现有方案缺口** → A-MEM 有完整的演化代码但无稳定性检验；DAM-LLM有熵度量理论但无通用化
↓
**本方案** → 将 DAM-LLM 的熵驱动思想适配为**通用记忆语义稳定性分数（SSS）**，门控 A-MEM 的演化触发条件——只有当记忆的稳定性分数低、且新记忆与其语义相关性高时，才触发 LLM 演化调用

---

### 🎯 切入点与 CCF C 类潜力

**适合单兵作战的理由**：
- A-MEM 的代码结构非常清晰，记忆演化是一个独立函数 `evolve_memories()`，修改点单一
- 新增的语义稳定性分数计算只需向量运算（嵌入余弦距离），无需 GPU
- 基准数据集 LoCoMo 和 DialSim 公开且易复现

**CCF C 类潜力**：
- 解决了原作者明确承认但未解决的问题，研究动机强
- 技术贡献聚焦且可验证：演化前后的记忆语义漂移量可以客观测量
- 双重收益：性能不下降 + 计算成本降低（减少不必要 LLM 调用），商业价值明显
- 对比实验设计简洁：A-MEM vs A-MEM+EntropyGate，同样数据集，指标明确

---

### ⚙️ 核心方法/融合机制设计

#### 整体思路

A-MEM 的每条记忆笔记 m_i 在其生命周期内可能经历多次演化。我们为每条笔记引入：

**语义稳定性分数（Semantic Stability Score, SSS）**

$$SSS(m_i) = 1 - \frac{1}{N_{evo}(m_i) + 1} \cdot \sum_{k=1}^{N_{evo}} \text{cosine\_drift}(m_i^{(k-1)}, m_i^{(k)})$$

其中：
- $N_{evo}(m_i)$：笔记 $m_i$ 已经历的演化次数
- $\text{cosine\_drift}(m_i^{(k-1)}, m_i^{(k)}) = 1 - \cos(e_i^{(k-1)}, e_i^{(k)})$：第 k 次演化前后嵌入向量的余弦漂移量

SSS 取值 [0, 1]，越接近 0 表示该笔记历次演化中语义漂移越大（越不稳定）。

#### 熵门控触发条件

借鉴 DAM-LLM 的熵阈值机制，将 A-MEM 的 `evolve_memories()` 由无条件触发改为**条件触发**：

```python
def entropy_gated_evolve(candidate_memory, new_memory, embed_model, llm):
    """
    判断是否对 candidate_memory 触发 LLM 演化
    """
    # 条件1: 语义相关性足够高（原 A-MEM 行为保留）
    semantic_relevance = cosine_similarity(candidate_memory.embedding,
                                           new_memory.embedding)
    if semantic_relevance < RELEVANCE_THRESHOLD:  # 默认 0.7
        return candidate_memory  # 不演化，直接返回原记忆

    # 条件2 (新增): 当前 SSS 足够低，说明该记忆还不稳定，允许继续演化
    if candidate_memory.sss < SSS_STABILITY_THRESHOLD:  # 默认 0.85
        # 记忆不稳定 + 新记忆相关 → 触发演化（正常情况）
        evolved = llm.evolve(candidate_memory, new_memory)
        # 更新 SSS
        drift = 1 - cosine_similarity(candidate_memory.embedding,
                                      embed(evolved.context))
        evolved.sss = update_sss(candidate_memory.sss, drift)
        return evolved
    else:
        # 记忆已稳定（SSS高）→ 即使新记忆相关也跳过演化，保护稳定记忆
        # 但可以为新记忆添加链接（Link）而非修改旧记忆内容（Evolution）
        create_link_only(candidate_memory, new_memory)
        return candidate_memory

# SSS 更新公式（移动平均）
def update_sss(current_sss, new_drift):
    alpha = 0.3  # 更新速率
    return current_sss * (1 - alpha) + (1 - new_drift) * alpha
```

#### 锚定重构机制（高漂移笔记的自我修正）

当检测到某笔记的 SSS 低于危险阈值（如 < 0.5）时，触发一次**锚定重构**：

```python
def anchor_reconstruction(unstable_memory):
    """
    对高漂移记忆进行锚定重构——从原始内容重新提取，而非在演化版本上继续演化
    """
    # 原始内容是 A-MEM 中存储的 content 字段（原始交互文本），从不被演化修改
    original_content = unstable_memory.original_content

    # 重新用原始 LLM 提取流程提取关键词、标签、上下文描述
    reconstruction_prompt = f"""
    Re-extract keywords, tags, and context from this original content:
    {original_content}
    Ignore any previous evolution of this memory.
    """

    fresh_extraction = llm.extract(reconstruction_prompt)
    unstable_memory.keywords = fresh_extraction.keywords
    unstable_memory.tags = fresh_extraction.tags
    unstable_memory.context = fresh_extraction.context
    unstable_memory.embedding = embed(original_content + fresh_extraction.keywords)
    unstable_memory.sss = 1.0  # 重置为满稳定状态

    return unstable_memory
```

`original_content` 在 A-MEM 的数据结构中对应 `c_i`（原始交互内容），我们只需在存储阶段保留一个不可变副本即可，无需架构大改动。

#### 与 DAM-LLM 连接

DAM-LLM 提出熵驱动的记忆管理公式：
- 高熵（H > 1.4） = 不确定性高 = 需要delete/merge
- 低熵（H < 0.8） = 确定性高 = 稳定记忆

本方案的 SSS 是 DAM-LLM 熵逻辑的自然延伸：**低 SSS（高漂移）**类比于**高熵（高不确定性）**，两者共同指向"记忆需要干预"的概念，但本方案针对的是通用文本记忆而非情感记忆。

---

### 🧪 实验方案（算力受限 + GitHub 优先）

**实验代码起点**：A-MEM GitHub 仓库
**具体修改点**：
1. `memory.py`（或等价文件）：在 MemoryNote 数据类中新增字段：`original_content`（不可变）、`sss`（浮点数，初始化为 1.0）、`evolution_embeddings`（嵌入历史列表）
2. `agent.py`（或等价文件）：修改 `evolve_memories()` 函数，添加 `entropy_gated_evolve` 判断逻辑
3. 周期性调用 `anchor_reconstruction()` 对 sss < 0.5 的笔记进行锚定重构

**评测环境**：
- OpenAI API 或 DeepSeek API（主要 LLM）
- all-MiniLM-L6-v2 或 all-mpnet-base-v2（本地嵌入）

**数据集**：
- LoCoMo（同 A-MEM 原论文，1,540 问题）
- DialSim（同 A-MEM 原论文）

**核心指标**：
- 任务性能：F1、BLEU-1（与 A-MEM 原论文数据直接对比）
- 记忆质量：平均 SSS 随时间的变化曲线（追踪稳定性是否提升）
- 效率：LLM 演化调用次数减少比例（预期减少 30-50%）
- 语义漂移量：每条记忆从初始到最终演化版本的平均余弦距离

**消融实验**：
1. A-MEM 原版（baseline）
2. A-MEM + SSS 门控（无锚定重构）
3. A-MEM + SSS 门控 + 锚定重构（完整方案）

---

### 📚 严格文献溯源与融合逻辑

| 论文 | 来源库 | 融合角色 |
|-----|-------|---------|
| **A-MEM**（Agentic Memory for LLM Agents） | **with_github** | **代码基础 + 系统架构主干**：evolve_memories() 函数为直接修改起点，MemoryNote 数据结构为扩展对象 |
| **DAM-LLM**（Dynamic Affective Memory Management） | **without_github** | **核心机制启发**：熵驱动的记忆健康度评估、阈值触发干预（merge/delete/update）思想被迁移和适配 |
| **Dynamic Cheatsheet** | **without_github** | **理论补强**：自我策展（self-curation）记忆管理思路验证了"并非所有记忆都应同等频繁更新"的核心假设 |

> 注：仅列出支撑 Method 的核心融合来源；最终论文 Related Work 需另行覆盖 15-20 篇。

---

### 🚀 第一步行动指南

1. **立即精读**：
   - A-MEM 论文的 Section 2.2（Memory Evolution，理解 P_s3 提示模板的触发时机）
   - A-MEM 代码中 `evolve_memories()` 的具体实现（找到条件判断函数）
   - DAM-LLM 的 Section 3.2（Entropy-driven memory compression 算法）

2. **优先跑通**：
   - Clone A-MEM GitHub 仓库
   - 运行 LoCoMo eval 脚本，复现 F1 baseline 数据
   - 打印 `evolve_memories()` 的调用频率（确认当前是无条件触发）

3. **第一个验证**：在 100 条对话上手动记录每条笔记的演化前后嵌入漂移量，验证是否存在高漂移记忆（SSS < 0.7），证明问题真实存在，为论文 Figure 1 积累数据

---
---

## 课题三

### 🏷️ 课题名称

**Query-Adaptive Multi-Strategy Memory Routing: Bridging Retrieval and Long-Range Understanding in Agent Memory Systems**

（查询自适应多策略记忆路由：弥合智能体记忆系统中检索精度与长程理解的鸿沟）

---

### 🔍 问题背景与研究动机（核心逻辑）

**① 当前存在什么明确缺陷？**

MemoryAgentBench（Evaluating Memory in LLM Agents via Incremental Multi-Turn Interactions，with_github）的核心发现是一个**系统性的能力悖论**：

| 能力维度 | RAG 类方法 | 长上下文方法 |
|---------|-----------|------------|
| 精确检索 (AR) | **优** | 差 |
| 测试时学习 (TTL) | 差 | **优** |
| 长程理解 (LRU) | 差（HippoRAG-v2 on ∞Bench-Sum: F1=14.6） | **优**（GPT-4o: F1=32.2, 超出 NAR 方法约120%） |
| 选择性遗忘 (SF) | 极差 | 极差（全部 ≤7%） |

论文明确指出：

> "任何基于检索（RAG）的记忆机制在需要全局整合信息的长程理解任务上均严重落后于长上下文模型。这表明**'检索即记忆'的范式存在理论天花板**，无法替代对完整上下文的整体理解。"

每种记忆系统基于固定的信息组织范式，无法根据查询类型动态切换策略。MEMENTO（with_github）进一步发现：即使记忆质量相同，增加检索 top-k 数量也会导致"信息过载"使性能下降（"协调失败"问题）。

**② 现有方法为什么无法解决？**

EverMemOS（with_github）已有一个精心设计的多组件检索系统（Dense+BM25 RRF + 验证器 + 查询重写），但无论查询类型如何，均走相同的固定流水线。其 Stage 3 对所有查询的处理逻辑相同：选前 N 个 MemScene，从中获取前 K 个 Episode，验证充分性，必要时重写查询。

结构性盲区：**不同查询类型对记忆粒度的需求不同** ——
- "昨天我说了什么?" → 需精确、近期、低粒度（AR 类型）
- "我这几个月的主要话题是什么?" → 需全局、高粒度、跨场景聚合（LRU 类型）
- "我说我要去北京但现在住在上海，现在住哪?" → 需时序冲突解析（SF 类型）

没有任何现有系统区分这些需求并分别优化。

**③ 融合方案如何精准弥补该缺口？**

**问题** → 记忆系统的单一固定策略无法同时满足所有查询类型
↓
**现有方案缺口** → EverMemOS 有强大的多组件检索但固定流水线；MemoryAgentBench 提供了 4 维能力分类但没有给出系统实现方向
↓
**本方案** → 在 EverMemOS 的 Stage 3 入口处添加**轻量级查询类型分类器（Query Type Router, QTR）**，根据分类结果调用不同的检索子策略，并在 MemoryAgentBench 基准上统一评测

---

### 🎯 切入点与 CCF C 类潜力

**适合单兵作战的理由**：
- 基于完整系统的一个路由层，代码修改量小：QTR 分类器 + Stage 3 的 if-else 分支
- QTR 分类器可用轻量级规则（关键词匹配+模式识别）实现，无需 GPU 训练
- 评测基准 MemoryAgentBench 已有 GitHub，可直接复用评测代码

**CCF C 类潜力**：
- 这是 benchmark→system 的闭环工作：MemoryAgentBench 发现了问题，本论文提供首个系统性解决方案
- 技术贡献具有明确的工程价值：模块化路由器可以集成到任何现有记忆系统
- 在所有 4 个能力维度上均有改善预期（而非单维度提升），结果更全面

---

### ⚙️ 核心方法/融合机制设计

#### 整体架构

```
输入查询 q
    ↓
[Query Type Router (QTR)] ← 轻量级分类
    ↓
 判断类型: AR / TTL / LRU / SF
    ↓
  ┌─────────────────────────────────┐
  │  AR策略  │ TTL策略 │ LRU策略 │ SF策略 │  ← EverMemOS Stage 3 四个子分支
  └─────────────────────────────────┘
    ↓
EverMemOS 后续处理（验证器、答案生成）
```

#### Query Type Router（QTR）设计

**轻量级三层分类方案**（无 GPU，无训练）：

**Layer 1：时间信号词检测**（规则，零成本）
```python
TEMPORAL_PATTERNS = {
    'recent': ['最近', '昨天', '上次', '刚才', 'recently', 'last time'],
    'historical': ['这几个月', '一直以来', 'overall', 'in general', '总体'],
    'conflict': ['但是现在', '已经变了', 'but now', 'changed to', '更新了']
}
```

**Layer 2：查询意图分类**（用轻量级 LLM 调用，约 20 tokens）
```python
QTR_PROMPT = """Classify this query into one of four types:
AR: Asks for a specific fact/event (e.g., "What did I say yesterday?")
TTL: Asks about recent learning/preference updates (e.g., "Have my opinions changed?")
LRU: Asks for synthesis across long time period (e.g., "What topics do I often mention?")
SF: Asks about something that may have been superseded (e.g., "Where do I live now?")

Query: {query}
Answer with exactly one: AR / TTL / LRU / SF"""
```

**Layer 3：置信度后处理**（规则补充）
- 如果 LLM 输出低置信度（通过让 LLM 输出置信度分数判断），默认回退到 AR 策略

#### 四种检索子策略（均基于 EverMemOS 现有组件）

**AR 策略（精确检索优先）**：
```python
def ar_retrieval(query, memscene_pool, N=10, K=5):
    # 优先使用 BM25（精确关键词匹配），减少 Dense 检索的比重
    scenes = retrieve_with_weight(query, memscene_pool, bm25_weight=0.7, dense_weight=0.3, top_N=N)
    # 直接选 Atomic Facts（不是 Episode），提高精确度
    facts = get_atomic_facts_from_scenes(scenes, top_K=K)
    return facts
```

**TTL 策略（近期优先）**：
```python
def ttl_retrieval(query, memscene_pool, N=5, K=5, recency_window=10):
    # 限制在最近 recency_window 个 MemScene 内搜索
    recent_scenes = get_recent_memscenes(memscene_pool, top_n=recency_window)
    scenes = retrieve_within_subset(query, recent_scenes, top_N=N)
    episodes = get_episodes_from_scenes(scenes, top_K=K)
    return episodes
```

**LRU 策略（全局聚合优先）**：
```python
def lru_retrieval(query, memscene_pool, N=20, summary_level='scene'):
    # 检索更多 MemScene（N=20 vs 默认 10），但使用场景级摘要（更高粒度）
    scenes = retrieve_with_weight(query, memscene_pool, top_N=N)
    # 返回每个 MemScene 的 Episode 摘要，而非原始 Episode
    summaries = [scene.get_summary() for scene in scenes]
    return summaries
```

**SF 策略（时序冲突解析）**：
```python
def sf_retrieval(query, memscene_pool, N=10, K=5):
    # 复用 Topic 1 的 FTVR 机制（如 Topic 1 已实现则直接调用）
    scenes = retrieve_with_weight(query, memscene_pool, top_N=N)
    # 过滤 SUPERSEDED 事实
    valid_facts = filter_superseded_facts(get_atomic_facts_from_scenes(scenes, top_K=K))
    return valid_facts
```

所有子策略都是对 EverMemOS 现有函数参数和调用顺序的调整，**无需重写核心检索逻辑**。

---

### 🧪 实验方案（算力受限 + GitHub 优先）

**实验代码起点**：EverMemOS GitHub（主干）+ MemoryAgentBench GitHub（评测框架）
**具体修改点**：
1. 新建文件 `query_router.py`：实现 QTR 的三层分类逻辑
2. `recall.py`（EverMemOS Stage 3）：在检索函数入口添加 QTR 调用，根据返回类型分支到不同子策略函数
3. （可选）`retrieval.py`：添加 `ar_retrieval`, `ttl_retrieval`, `lru_retrieval`, `sf_retrieval` 四个子函数

**评测环境**：
- DeepSeek-V3 API（QTR 分类用 mini 模型，主要推理用标准模型）
- all-MiniLM-L6-v2（本地嵌入）
- MemoryAgentBench 的评测脚本（直接复用）

**数据集**：
- MemoryAgentBench 的四个能力维度数据集（AR: SH-Doc QA; TTL: MCC; LRU: ∞Bench-Sum; SF: FactCon-MH）

**核心指标**：
- 四个维度的准确率/F1（与 EverMemOS baseline 及各 SOTA 方法对比）
- 错误路由率（QTR 分类错误导致的性能损失）
- QTR 分类耗时（需控制在可忽略范围内）

**消融实验**：
1. EverMemOS 原版（固定流水线）
2. EverMemOS + QTR（规则层，无 LLM）
3. EverMemOS + QTR（完整三层）

---

### 📚 严格文献溯源与融合逻辑

| 论文 | 来源库 | 融合角色 |
|-----|-------|---------|
| **EverMemOS** | **with_github** | **代码基础 + 系统架构主干**：Stage 3 检索管道为直接修改起点，MemCell/MemScene 结构被四种子策略复用 |
| **MemoryAgentBench**（Evaluating Memory...） | **with_github** | **创新问题发现 + 评测框架**：四维能力分类（AR/TTL/LRU/SF）直接指导路由器设计；评测代码直接复用 |
| **MEMENTO**（Embodied Agents Meet Personalization） | **with_github** | **改进机制启发**：信息过载导致协调失败的实验发现，支持查询自适应路由的必要性 |

> 注：仅列出核心融合来源；Related Work 需另行覆盖。

---

### 🚀 第一步行动指南

1. **立即精读**：
   - MemoryAgentBench 论文的 Table 1（四维评测结果完整数据）和 Section 4.4（消融分析）
   - EverMemOS 的 Section 3.3（Stage 3 重构回忆算法）+ 代码中 `recall.py` 的函数签名

2. **优先跑通**：
   - Clone MemoryAgentBench GitHub，运行 EverMemOS 在四个任务上的 baseline 评测
   - 验证 EverMemOS 在 LRU 任务（∞Bench-Sum）上确实不如长上下文模型

3. **第一个实验**：手动随机采样 50 个查询，用 Layer 1 规则分类器分类，验证时间信号词的准确率（是否能粗略区分 AR vs LRU），确认规则基础可行性

---
---

## 课题四

### 🏷️ 课题名称

**Boundary-Aware Experience Retrieval: Structural Compatibility Filtering for Cross-Context Memory Transfer in Knowledge-Augmented Agents**

（边界感知经验检索：面向知识增强型智能体的结构相容性预过滤机制）

---

### 🔍 问题背景与研究动机（核心逻辑）

**① 当前存在什么明确缺陷？**

ChemAgent（with_github）在其局限性章节明确承认：

> "记忆检索的误导性：系统依赖向量相似度检索记忆，但**语义相似的任务可能在关键细节上不同**（例如，一个过程是绝热的而另一个不是），这可能导致检索到**看似相关实则误导的记忆**，引发连锁错误。论文指出这是尚未解决的挑战。"

AGENT KB（with_github）进一步报告了**跨领域知识迁移不对称性**：

> "SWE经验在GAIA任务上准确率仅56.4%，而推理经验在SWE任务仍能达到37.0%。这表明当前抽象方法对高度领域特异性（如代码语法）的泛化能力有限。"

其根本原因是：**语义嵌入（Dense Embedding）捕捉的是高层语义相似性，无法区分同一任务类型下的关键结构性差异**（如相同化学问题但热力学过程不同；同是代码任务但语言/框架完全不同）。

两者都提出了方向性建议但没有系统实现：ChemAgent 建议"轻量级规则过滤器"，AGENT KB 暗示"更好的抽象机制"。

**② 现有方法为什么无法解决？**

AGENT KB 的混合检索（BM25 + 语义嵌入，α=0.5）和分歧门（divergence gate）都在**结果层面**做保障：分歧门检查的是"原始计划与精炼计划的相似度"，即在经验已被应用之后才判断是否接受。这是**后验过滤（post-hoc filtering）**，无法阻止误导性经验被整合到推理过程中。

问题的根源在于**检索前没有结构级别的预过滤**：检索时只看"任务描述的语义相似度"，不看"任务的结构特征是否兼容"。

**③ 融合方案如何精准弥补该缺口？**

**问题** → 相似语义不等于可迁移结构，误导性检索导致连锁错误
↓
**现有方案缺口** → AGENT KB 有后验分歧门但无前验结构过滤；ChemAgent 提出方向但无实现；EvolveR 有效用评分但只基于成功率不基于结构
↓
**本方案** → 在 AGENT KB 的混合检索之后、整合阶段之前，添加一个**结构相容性预过滤层（Structural Compatibility Pre-Filter, SCPF）**：在经验存储时提取"边界标记（boundary markers）"，在检索时计算查询任务与候选经验的边界相容性分数，过滤掉相容性低的经验

---

### 🎯 切入点与 CCF C 类潜力

**适合单兵作战的理由**：
- AGENT KB 的检索管道是模块化的，SCPF 是一个独立的后处理层，不需要修改混合检索核心
- 边界标记提取可通过 LLM 调用实现，无训练需求
- 与 AGENT KB 原有数据集（GAIA）完全兼容，对比实验直接

**CCF C 类潜力**：
- 将两篇已发表论文各自承认但未解决的限制联合成一个完整解决方案，创新点充分
- 前验过滤 vs 后验门控是有原则的改进，理论贡献清晰
- 应用场景广（任何需要经验迁移的 agent 系统），工程价值高

---

### ⚙️ 核心方法/融合机制设计

#### 边界标记（Boundary Markers）的定义

边界标记是一组描述任务的**结构级元数据**，区分于任务的语义描述。对于 AGENT KB 的经验单元 $E = \langle \pi, \gamma, S, \mathcal{C} \rangle$，我们在 $\mathcal{C}$（跨框架兼容性元数据）中扩展边界标记集合 $\mathcal{B}$：

```python
BoundaryMarkers = {
    # 领域结构特征
    "domain_type": "scientific_reasoning | code_engineering | web_search | math",
    "sub_domain": "chemistry | physics | python | javascript | ...",

    # 工具/API 依赖
    "required_tools": ["python_executor", "calculator", ...],
    "tool_categories": ["code_interpreter", "search_engine", ...],

    # 推理模式
    "reasoning_pattern": "deductive | inductive | step_by_step | comparison",
    "multi_step_depth": 1 | 2 | 3 | "deep",  # 推理链长度

    # 约束条件（化学例子：等温/绝热/等压）
    "key_constraints": ["isothermal", "reversible_process", ...]  # 领域特定约束词
}
```

边界标记提取通过 LLM 调用在**经验存储时**一次性完成（非实时），后续检索时只需比较这些结构化标记，成本可控。

#### SCPF 算法

```python
def structural_compatibility_prefilter(query_task, retrieved_experiences, llm, embed_model):
    """
    在 AGENT KB 混合检索之后、整合阶段之前执行
    """
    query_markers = extract_boundary_markers(query_task, llm)

    compatible_experiences = []
    for exp in retrieved_experiences:
        compatibility_score = compute_compatibility(query_markers, exp.boundary_markers)

        if compatibility_score >= COMPATIBILITY_THRESHOLD:  # 默认 0.6
            compatible_experiences.append((exp, compatibility_score))
        else:
            # 不过滤掉，改为降权（避免丢失有价值的跨领域洞察）
            compatible_experiences.append((exp, compatibility_score * 0.3))

    # 按综合分数（语义相似度 × 相容性分数）重排序
    combined_ranking = [(exp, sem_sim * comp_score)
                        for exp, comp_score, sem_sim in zip_with_semantic_scores(...)]

    return sorted(combined_ranking, key=lambda x: x[1], reverse=True)[:K]

def compute_compatibility(query_markers, exp_markers):
    """
    计算两个任务边界标记集合的相容性分数
    采用加权组合：
    - domain_type 完全匹配: +0.4
    - required_tools 重叠率: +0.3
    - reasoning_pattern 相似: +0.2
    - key_constraints 无冲突: +0.1
    """
    score = 0.0

    # 领域类型精确匹配（最重要的边界）
    if query_markers.domain_type == exp_markers.domain_type:
        score += 0.4
    elif are_related_domains(query_markers.domain_type, exp_markers.domain_type):
        score += 0.2

    # 工具重叠度（Jaccard 系数）
    tool_overlap = len(set(query_markers.required_tools) & set(exp_markers.required_tools))
    tool_union = len(set(query_markers.required_tools) | set(exp_markers.required_tools))
    score += 0.3 * (tool_overlap / max(tool_union, 1))

    # 推理模式相似度（简单字符串匹配）
    if query_markers.reasoning_pattern == exp_markers.reasoning_pattern:
        score += 0.2

    # 关键约束无冲突（借鉴 ChemAgent 的启发：化学过程类型等约束词）
    conflicts = detect_constraint_conflicts(query_markers.key_constraints,
                                           exp_markers.key_constraints)
    if not conflicts:
        score += 0.1

    return score
```

#### 与 EvolveR 的连接

EvolveR（with_github）的动态效用分数 $s(p) = (c_{succ}+1)/(c_{use}+2)$ 度量的是经验在实际使用中的**历史成功率**。我们可以将 EvolveR 的效用分数与 SCPF 的相容性分数**线性融合**，形成更鲁棒的综合排序分数：

$$\text{Score}(exp, query) = \alpha \cdot \text{SemanticSim}(exp, query) + \beta \cdot \text{CompatScore}(exp, query) + \gamma \cdot \text{UtilityScore}(exp)$$

其中 $\alpha + \beta + \gamma = 1$，默认 $\alpha=0.5, \beta=0.3, \gamma=0.2$。这三者分别来自 AGENT KB 的混合检索、本方案的 SCPF、EvolveR 的效用评分，且都不需要训练。

---

### 🧪 实验方案（算力受限 + GitHub 优先）

**实验代码起点**：AGENT KB GitHub 仓库
**具体修改点**：
1. `experience_store.py`（或等价文件）：在经验存储函数中添加 `extract_boundary_markers()` 调用，将边界标记写入 $\mathcal{C}$ 字段
2. `retrieval.py`：在混合检索返回结果后，调用 `structural_compatibility_prefilter()` 进行重排序
3. 新建 `boundary_markers.py`：实现边界标记提取和相容性计算逻辑

**评测环境**：
- DeepSeek-V3 API（边界标记提取用一次 LLM 调用，主推理用主模型）
- GAIA 基准数据集（与 AGENT KB 论文完全相同的评测设置）

**数据集**：
- GAIA（Level 1/2/3，与 AGENT KB 原论文对比）
- 可选：ChemAgent 的 SciBench 化学数据集（验证在专业领域的过滤效果）

**核心指标**：
- GAIA 准确率（总体 + 分 Level）
- 误导性经验比例（被 SCPF 过滤掉但实际上有用的经验 vs 被正确过滤的误导性经验）
- 边界标记提取准确率（人工标注 50 个样本验证）

**消融实验**：
1. AGENT KB 原版（baseline）
2. AGENT KB + SCPF（仅领域类型过滤）
3. AGENT KB + SCPF（完整边界标记）
4. AGENT KB + SCPF + 效用分数融合（引入 EvolveR 思路）

---

### 📚 严格文献溯源与融合逻辑

| 论文 | 来源库 | 融合角色 |
|-----|-------|---------|
| **AGENT KB** | **with_github** | **代码基础 + 系统架构主干**：混合检索管道（BM25+语义）、分歧门、经验结构 E=<π,γ,S,C> 均为直接修改起点；SCPF 插入在已有检索后 |
| **ChemAgent** | **with_github** | **创新问题发现**：明确指出"语义相似但关键约束不同导致误导性检索"是未解决的挑战，定义了 key_constraints 边界标记的设计依据 |
| **EvolveR** | **with_github** | **改进机制**：提供效用分数 $s(p)$ 的计算逻辑，作为相容性分数的第三维补充，增强综合排序的鲁棒性 |

> 注：with_github 论文占 3/3（100%），完全满足"至少60%来自with_github"的约束。仅列核心来源，Related Work 需另行覆盖。

---

### 🚀 第一步行动指南

1. **立即精读**：
   - AGENT KB 的 Section 3.2（两阶段混合检索实现细节）和 Section 4.2（领域知识转移不对称性实验）
   - ChemAgent 的 Section 4.3（Case Study：哪类任务发生了误导性检索）

2. **优先跑通**：
   - Clone AGENT KB GitHub 仓库
   - 运行 GAIA eval，复现 55.2% → 73.9% 的结果（baseline 确认）
   - 找到 `retrieval.py` 中混合检索的入口函数

3. **第一个验证**：从 GAIA 数据集中随机采样 20 个 Level 3 任务失败案例，手动分析检索到的经验是否存在领域/工具不匹配（验证问题是否普遍存在，为论文 Motivation Section 积累数据）

---

## 附录：课题间关联与研究路线建议

```
Topic 1 (FactValidity - EverMemOS)
    ↕        ← SF策略直接复用 Topic 1 的 FTVR 机制
Topic 3 (QueryRouter - EverMemOS)
         ← 两者共享 EverMemOS 代码基座，可在同一代码库并行实验

Topic 2 (EntropyGate - A-MEM)
         ← 独立基座，可并行开展

Topic 4 (BoundaryAware - AGENT KB)
         ← 独立基座，可并行开展
```

**推荐优先级**：
1. **Topic 1**：问题最清晰（≤7% baseline），预期提升最明显，实验成本低，**建议首选**
2. **Topic 2**：A-MEM生态成熟，代码修改量最小，适合算力最受限时
3. **Topic 3**：基于 MemoryAgentBench 框架，实验设计最完整，适合已建立 EverMemOS 基础后扩展
4. **Topic 4**：AGENT KB 验证场景（GAIA）最通用，适合追求应用影响力

---

*文档结束*

**生成模型**：Claude Sonnet 4.6 (claude-sonnet-4-6)
**生成时间**：2026-03-06 15:30:00
**总字数**：约 12,000 字
