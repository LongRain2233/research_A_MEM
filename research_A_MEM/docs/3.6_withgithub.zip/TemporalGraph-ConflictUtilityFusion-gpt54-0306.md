﻿# Agent Memory 问题驱动融合选题文档

- 生成时间：2026-03-06 20:20:43
- 生成模型：GPT-5.4

## 第0步：问题诊断
基于 `with_github` 与 `without_github` 两组文献，当前 Agent Memory 中最值得切入、且被反复承认但尚未被解决的瓶颈有 4 个：

1. **细节丢失与有损压缩**
   - `A Simple Yet Strong Baseline for Long-Term Conversational Memory of LLM Agents` 明确指出，会话级检索、摘要或三元组提取都会割裂原始话语连贯性；其 EDU 方案虽然更强，但仍会压缩态度、风格与偏好信息。
   - `Nemori` 在 `single-session-assistant` 上低于 Full Context，说明结构化记忆仍会丢细节。
   - `Goal-Directed Search Outperforms Goal-Agnostic Memory Compression` 进一步证明：目标无关压缩会在后续查询时丢失关键细节。

2. **知识冲突、时序更新与记忆漂移处理不足**
   - `A-MEM` 自承其持续演化缺乏稳定性保证，在冲突信息持续涌入时可能出现表示漂移与链接混乱。
   - `CAM` 明确假设输入信息内部一致，无法处理矛盾事实。
   - `Zep` 虽有 `t_valid/t_invalid` 机制，但高度依赖 LLM 时间解析，且在部分任务上会退化。
   - `HaluMem` 揭示多数系统更新遗漏率极高，且上游提取错误会在更新与 QA 阶段持续放大。

3. **记忆碎片化与检索噪声**
   - `SGMem` 直接把核心问题定义为 memory fragmentation：原始对话块、摘要、事实、洞察彼此脱节。
   - `ComoRAG` 指出多步检索虽能迭代，但若没有跨轮记忆状态，证据仍然碎片化，且难以整合冲突信息。
   - `THEANINE`（without_github）表明时间线级检索优于被打乱的传统检索，说明“检索到相关片段”不等于“得到可推理上下文”。

4. **在线更新成本高，且缺少效用驱动遗忘/准入**
   - `A-MEM` 写入成本随记忆库线性增长。
   - `SGMem` 与 `ComoRAG` 都缺乏显式遗忘；前者图会线性膨胀，后者记忆池只增不减。
   - `SEDM`（without_github）指出，仅按相似度写入会把噪声和低价值经验一并留下，必须引入“效用”维度。

## 第0.5步：with_github 结构主干候选
以下 5 篇最适合作为“代码主干候选”。

| 论文 | 记忆数据结构 | 检索机制 | 遗忘/更新策略 | 模块级可改性 | 适合担当的主干角色 |
| --- | --- | --- | --- | --- | --- |
| `A-MEM` | 原子笔记 + 动态链接网络 | 向量 Top-k 检索 | LLM 驱动链接生成与记忆演化，无显式遗忘 | 很高，主逻辑集中在 `memory_layer.py` | 最适合做“可改写的长期记忆主干” |
| `Zep / Graphiti` | 情景-语义-社区三层时序知识图谱 | 语义检索 + BM25 + BFS + 重排 | 冲突边失效、社区近似增量更新 | 很高，`graphiti_core` 下结构清晰 | 最适合做“时序冲突与结构检索主干” |
| `CAM` | 增量重叠聚类的层次记忆图 | Prune-and-Grow 检索 | 动态增量聚类，但无冲突处理与遗忘 | 很高，核心集中在 `prototype/constructivist_memory.py` | 最适合做“层次化记忆整合主干” |
| `ComoRAG` | 动态记忆工作空间 + 三层知识源 | Self-Probe + Tri-Retrieve + Mem-Fuse | 记忆池只增不减，无准入门控 | 很高，核心集中在 `src/comorag/ComoRAG.py` | 最适合做“多步状态化推理主干” |
| `SGMem` | 句子图 + 7 类向量索引 | 多索引向量检索 + h-hop 图扩展 | 基本无遗忘，仅静态扩展 | 中高，句子图和检索逻辑边界清晰 | 最适合做“细粒度对话记忆主干” |

**综合首选主干候选：`A-MEM`**。
原因：代码入口最集中、写入与更新逻辑最清楚、最适合做低算力下的“机制微调”，并且能自然吸收 `Zep` 的时序约束和 `HaluMem` 的操作级诊断。

## 第1步：领域过滤结果
### with_github 组中最值得优先投入的有效文献
- `A-MEM`
- `Zep / Graphiti`
- `CAM`
- `ComoRAG`
- `SGMem`
- `HaluMem`
- `Goal-Directed Search Outperforms Goal-Agnostic Memory Compression`

### without_github 组中最有价值的“问题/机制启发”
- `PREMem`：预存储推理与跨会话记忆演化模式。
- `SEDM`：效用驱动的记忆准入、自调度与剪枝。
- `Towards Lifelong Dialogue Agents via Timeline-based Memory Management`：时间线级检索与精炼。
- `Rethinking Memory in LLM based Agents`：动态操作视角，尤其是更新与遗忘长期被低估。

## 第2-4步：可立即启动的 4 个课题方向

---

### 课题 1
🏷️ 课题名称：
**Temporal Validity-Aware Note Evolution for Agent Memory**

🔍 问题背景与研究动机（核心逻辑）：
1. 当前哪里坏了：`A-MEM` 虽然引入了动态演化，但论文明确承认“持续、LLM 驱动的演化缺乏理论保证”，在冲突或低质量新记忆涌入时会产生**记忆漂移、语义失真与链接混乱**。`HaluMem` 又证明，多数系统在“更新”阶段遗漏率极高，上游提取错误会持续传播。
2. 现有方法为何没解决：`A-MEM` 只有“相似检索 + LLM 更新”，缺少**时间有效性约束**；`Zep` 有 `t_valid/t_invalid`，但它的完整图谱体系更重，且并不适合直接替代 A-MEM 的轻量笔记主干。
3. 我的融合方案：保留 `A-MEM` 的原子笔记与动态链接主干，只把 `Zep` 中最关键的“**时间有效边/事实失效**”机制压缩迁移进来，再用 `HaluMem` 的操作级指标去诊断“提取错了”还是“更新错了”。这形成了明确的链条：
   **A-MEM 漂移/冲突风险 -> 现有相似检索式更新缺少时间约束 -> 用时间有效性修正 A-MEM 的演化逻辑。**

🎯 切入点与 CCF C 类潜力：
这是非常适合单兵作战的题目。因为它不是重写系统，而是对 `A-MEM` 的写入、更新、检索三段逻辑做精细机制改造；实验也可直接复用 `LoCoMo`、`LongMemEvalS`、`HaluMem`。创新点不在“大模型更强”，而在**把动态演化从“语义相似更新”推进到“时间有效性约束更新”**，有较强 CCF C 类投稿可行性。

⚙️ 核心方法/融合机制设计：
- 以 `A-MEM` 的 note 作为主存储单元，但把 note 从 `{content, keyword, tag, context, embedding, links}` 扩展为 `{content, type, valid_from, valid_to, confidence, conflict_group, links}`。
- 写入时先做**轻量级预判**：从新消息中抽取实体、时间表达和记忆类型（事实/经验/主观），只对可能冲突的候选触发 API 仲裁。
- 更新时不再只有 `ADD/UPDATE`，而是引入 `SUPERSEDE/COEXIST/REFINE`：
  - 同一实体同一属性且时间重叠时，触发 `SUPERSEDE`，旧记忆 `valid_to` 关闭；
  - 主观偏好或多视角经验则 `COEXIST`，禁止粗暴覆盖；
  - 仅细节补充时执行 `REFINE`。
- 检索时采用三项重排：`semantic_score × validity_score × conflict_penalty`。若问题带时间线索，则优先返回时间上仍有效的笔记；若无时间线索，则同时返回最新有效条目与最近失效条目，避免“更新后无法解释变化原因”。

🧪 实验方案（算力受限 + GitHub 优先）：
- 实验起点源码：`WujiangXu/A-mem`。
- 直接修改模块：`memory_layer.py`、`llm_text_parsers.py`、`test_advanced.py`。
- 数据集：`LoCoMo`、`LongMemEvalS`、`HaluMem-Medium/Long`。
- API：`gpt-4o-mini` 或 `DeepSeek-V3` 用于冲突仲裁与结构化抽取；本地仅用 `all-MiniLM-L6-v2` 或 `bge-small-zh-v1.5` 做嵌入。
- 关键指标：F1 / Accuracy / BLEU-1 + `HaluMem` 的 extraction recall、update accuracy、hallucination rate、omission rate。
- 消融：去掉时间有效性；去掉冲突分流；只保留语义相似更新。

📚 严格文献溯源与融合逻辑：
- `A-MEM`【with_github】
  - 贡献：**代码基础 + 主干结构 + 可直接修改源码实现**。
- `ZEP: A Temporal Knowledge Graph Architecture for Agent Memory`【with_github】
  - 贡献：**时间有效性与冲突失效机制**。
- `HaluMem`【with_github】
  - 贡献：**操作级问题发现与评测框架**。
- `Pre-Storage Reasoning for Episodic Memory`【without_github】
  - 贡献：**记忆类型区分与跨会话演化启发**。

🚀 第一步行动指南：
- 先精读 `A-MEM` 论文中的 note construction、link generation、memory evolution 三节，以及 `Zep` 的 `t_valid/t_invalid` 设计。
- 代码先跑通 `WujiangXu/A-mem` 的 `memory_layer.py` 与 `llm_text_parsers.py`。
- 第一版先只做两件事：给 note 增加 `valid_from/valid_to` 字段；在更新逻辑里插入 `SUPERSEDE/COEXIST/REFINE` 三分类。

---

### 课题 2
🏷️ 课题名称：
**Conflict-Aware Constructivist Memory for Inconsistent Long Documents**

🔍 问题背景与研究动机（核心逻辑）：
1. 当前哪里坏了：`CAM` 明确承认它和 `GraphRAG/RAPTOR/MemTree` 一样，**假设输入文本内部一致**。一旦文档中出现矛盾事实、观点变化或时序更新，层次摘要就可能把冲突信息错误合并。
2. 现有方法为何没解决：`CAM` 的优势在于增量聚类与层次构图，但它没有“冲突检测/冲突隔离”层；`Zep` 能处理时序失效，却主要面向对话与动态图谱，不擅长层次阅读记忆整合。
3. 我的融合方案：以 `CAM` 的增量重叠聚类为主干，把 `Zep` 的“时间有效/冲突失效”思想迁入 chunk-level memory construction，再用 `HaluMem` 的操作级评估思想，把“冲突是在构图阶段被引入，还是在摘要阶段被放大”拆开测。链条是：
   **CAM 的一致性假设 -> 层次摘要会把矛盾源错误聚合 -> 加入冲突检测与冲突隔离节点，避免幻觉向高层传播。**

🎯 切入点与 CCF C 类潜力：
这是一个典型“机制微创新 + 评测轻扩展”题目，不需要训练大模型，只要改 `CAM` 的构图和检索逻辑，再做一个小规模矛盾注入评测集即可。对 CCF C 类很友好，因为问题定义明确、改动集中、可复现实验路径清晰。

⚙️ 核心方法/融合机制设计：
- 保留 `CAM` 的 `基础网络扩展 -> 自我中心解耦 -> 在线聚类更新` 主流程。
- 在 `preprocess_chunks` 阶段增加**冲突探测器**：对相似 chunk 的实体-属性-时间片进行比较，若语义近但主张相反，则不直接连边，而是创建 `conflict anchor node`。
- 在 `constructivist_memory` 中，允许高层抽象节点引用“普通证据簇”和“冲突簇”两类子节点；冲突簇默认不进入普通摘要，而是生成 `controversy note`。
- 检索时采用双通路：
  - 默认回答路径走普通抽象节点；
  - 若 query 包含“后来/现在/仍然/是否变化”等更新线索，强制打开冲突簇并做时间排序。

🧪 实验方案（算力受限 + GitHub 优先）：
- 实验起点源码：`rui9812/CAM`。
- 直接修改模块：`prototype/constructivist_memory.py`、`prototype/preprocess_chunks.py`、`prototype/tasks/question_answering.py`。
- 数据集：`NovelQA`、`QMSum`，外加一个低成本自建 `Conflict-QMSum` 小集合（把会议决议、人物立场、事件状态做显式更新注入）。
- API：`gpt-4o-mini` 仅用于冲突标签与高层摘要；本地嵌入沿用原仓库。
- 指标：ACC-L / Rouge-L / 冲突问题准确率 / 冲突误合并率。

📚 严格文献溯源与融合逻辑：
- `CAM`【with_github】
  - 贡献：**代码基础 + 层次增量聚类主干 + 直接修改源码实现**。
- `ZEP`【with_github】
  - 贡献：**冲突事实失效与时间表达机制**。
- `HaluMem`【with_github】
  - 贡献：**“提取-更新-问答”分阶段诊断思想**。

🚀 第一步行动指南：
- 先精读 `CAM` 的 `incremental overlapping clustering`、`Prune-and-Grow` 两节。
- 代码先看 `prototype/preprocess_chunks.py` 和 `prototype/constructivist_memory.py`。
- 第一版先不追求复杂规则，只做“相似 chunk 但主张相反时创建冲突锚点，不允许直接进入普通摘要簇”。

---

### 课题 3
🏷️ 课题名称：
**Utility-Gated Dynamic Workspace for Stateful Narrative Reasoning**

🔍 问题背景与研究动机（核心逻辑）：
1. 当前哪里坏了：`ComoRAG` 的记忆池在 `Mem-Update` 中是直接并集扩张，论文也承认 `Self-Probe` 若生成低质量探测查询，错误会在记忆池中累积，且缺少明确终止置信度。
2. 现有方法为何没解决：`ComoRAG` 解决了“有无状态化工作空间”的问题，却没有解决“哪些 memory unit 值得写入与保留”；`SEDM` 则指出，仅靠相似性检索无法区分高价值经验与噪声，必须引入效用权重与准入门控。
3. 我的融合方案：保留 `ComoRAG` 的动态工作空间，但在 `Mem-Update` 前加一个**utility gate**，只把真正提升后续回答质量的记忆单元写入；同时加轻量遗忘，避免工作空间膨胀。链条是：
   **ComoRAG 记忆池只增不减 -> 错误探测会污染后续推理 -> 用效用门控决定“写不写、留多久、检索优先级多高”。**

🎯 切入点与 CCF C 类潜力：
这是标准的“把一个强框架从可用推进到可部署”的选题。因为你不需要训练 RL，只要设计廉价的 utility proxy 即可；实验还能同时报告性能、token、API 成本和记忆池规模，论文叙事很完整。

⚙️ 核心方法/融合机制设计：
- 主干仍为 `Self-Probe -> Tri-Retrieve -> Mem-Encode -> Mem-Fuse -> Try-Answer -> Mem-Update`。
- 新增 `Mem-Assess`：对每个新记忆单元计算 `utility = answer_delta + citation_overlap + self_consistency - redundancy_penalty`。
- 仅当 `utility > tau` 时写入全局记忆池；若 `utility` 低但和高价值记忆高度相似，则并入已有记忆单元而不是新增。
- 检索分数由 `semantic_score × utility_score × freshness_score` 组成；低 utility 单元会时间衰减更快。
- 若 `Try-Answer` 低置信且当前新增记忆 utility 仍低，则提前终止，避免无效循环。

🧪 实验方案（算力受限 + GitHub 优先）：
- 实验起点源码：`EternityJune25/ComoRAG`。
- 直接修改模块：`src/comorag/ComoRAG.py`、`src/comorag/embedding_store.py`、`src/comorag/rerank.py`、`main_openai.py`。
- 数据集：`NarrativeQA`、`EN.QA`、`EN.MC`、`DetectiveQA`。
- API：`gpt-4o-mini` 或 `DeepSeek-V3`；本地嵌入用 `BGE-M3` 或仓库默认模型。
- 指标：ACC / F1 / 平均循环轮数 / 平均记忆池大小 / 每题 token 成本。
- 关键消融：无 utility gate、只做写入门控、不做遗忘、只做遗忘不做门控。

📚 严格文献溯源与融合逻辑：
- `ComoRAG`【with_github】
  - 贡献：**代码基础 + 动态记忆工作空间主干 + 直接修改源码实现**。
- `HaluMem`【with_github】
  - 贡献：**错误传播路径启发，提醒要防止低质量记忆进入下游**。
- `SEDM`【without_github】
  - 贡献：**效用驱动的记忆准入、自调度与剪枝思想**。

🚀 第一步行动指南：
- 先精读 `ComoRAG` 的 `Mem-Encode / Mem-Fuse / Mem-Update` 三段。
- 代码先看 `src/comorag/ComoRAG.py`。
- 第一版先不要做复杂学习，只实现一个启发式 utility：`答案自一致 + 与问题实体重叠 + 与已有记忆冗余惩罚`。

---

### 课题 4
🏷️ 课题名称：
**Dual-Path Raw Search and Temporal Graph Retrieval for Precision Conversational Memory**

🔍 问题背景与研究动机（核心逻辑）：
1. 当前哪里坏了：`Zep` 在复杂时序和多会话上很强，但论文承认在某些需要完整连续上下文的任务上会退化；另一方面，`Goal-Directed Search` 证明原始未压缩记忆搜索对精确回忆很有优势。
2. 现有方法为何没解决：今天的系统大多在“结构化图谱检索”和“原始记忆搜索”之间二选一。`Zep` 强于结构关系，弱于逐字细节；搜索式方法强于细节，弱于高层关系与世界状态组织。
3. 我的融合方案：以 `Zep/Graphiti` 为结构主干，同时引入一条**raw episodic search** 支路；由查询分类器决定走 `graph-first`、`raw-first` 或 `dual-path`，最后再做统一重排。链条是：
   **结构检索会丢逐字细节 -> 原始搜索虽准但缺少关系组织 -> 做查询自适应双路径检索，而不是预设单一路径。**

🎯 切入点与 CCF C 类潜力：
这个题目最像“工程机制创新”，但问题非常真实，而且与 `single-session-assistant / knowledge-update / temporal-reasoning` 三类任务的性能差异高度对应。因为主干代码成熟、改动点集中在检索层，所以十分适合低算力独立推进。

⚙️ 核心方法/融合机制设计：
- 保留 `Graphiti` 的三层图谱与混合检索框架。
- 为每个 episodic node 增加**raw sentence span/back-pointer**，保证能回退到原始消息片段。
- 新增查询路由器：
  - 若 query 含“具体怎么说/原话/哪天/第几次/谁先说”等线索，走 `raw-first`；
  - 若 query 更像“关系变化/长期偏好/跨会话整合”，走 `graph-first`；
  - 若 query 同时要求精确细节和关系演化，走 `dual-path`。
- 最终重排分三项：`exact_match_score + temporal_consistency_score + graph_connectivity_score`。
- 对 raw 检索结果附加前后 1-2 条消息，吸收 `Goal-Directed Search` 的局部上下文组装思想。

🧪 实验方案（算力受限 + GitHub 优先）：
- 实验起点源码：`getzep/graphiti`。
- 直接修改模块：`graphiti_core/graphiti.py`、`graphiti_core/graph_queries.py`、`graphiti_core/search/search.py`、`graphiti_core/search/search_config.py`。
- 数据集：`LongMemEval`、`LoCoMo`，重点报 `single-session-assistant`、`multi-session`、`temporal-reasoning` 子集；再用 `HaluMem` 补充更新相关诊断。
- API：OpenAI / DeepSeek 做实体事实抽取；本地 `BGE-M3` 做向量检索；BM25 全部本地。
- 关键指标：Accuracy、不同子任务提升、平均上下文 token、延迟。

📚 严格文献溯源与融合逻辑：
- `ZEP`【with_github】
  - 贡献：**代码基础 + 结构主干 + 直接修改源码实现**。
- `GOAL-DIRECTED SEARCH OUTPERFORMS GOAL-AGNOSTIC MEMORY COMPRESSION`【with_github】
  - 贡献：**原始记忆搜索与局部上下文组装机制**。
- `SGMem`【with_github】
  - 贡献：**细粒度句子级锚点与图扩展启发**。
- `Towards Lifelong Dialogue Agents via Timeline-based Memory Management`【without_github】
  - 贡献：**时间线精炼与顺序保持启发**。

🚀 第一步行动指南：
- 先精读 `Zep` 的搜索函数 `f(alpha)=chi(rho(phi(alpha)))` 以及 `Goal-Directed Search` 的 raw memory group 设计。
- 代码先看 `graphiti_core/search/search.py` 和 `graphiti_core/graphiti.py`。
- 第一版只做最小改动：增加 `raw-first` 路由和 back-pointer 回退，不必一开始就做复杂三路融合。

## 最终建议的启动优先级
1. **课题 1：Temporal Validity-Aware Note Evolution**
   - 最适合马上开工，代码主干最清晰，论文故事最完整。
2. **课题 4：Dual-Path Raw Search and Temporal Graph Retrieval**
   - 工程实现性很高，结果也最容易在子任务上打出明显提升。
3. **课题 3：Utility-Gated Dynamic Workspace**
   - 适合做“性能-成本-记忆规模”三维权衡型论文。
4. **课题 2：Conflict-Aware Constructivist Memory**
   - 创新感强，但需要你自己做一个小型冲突评测集，准备时间略长。

## 一句话判断
如果你的目标是**尽快做出一篇最稳的 CCF C 保底稿**，优先选 **课题 1**；如果你更想做一个“检索机制更漂亮、实验更好看”的方向，优先选 **课题 4**。
