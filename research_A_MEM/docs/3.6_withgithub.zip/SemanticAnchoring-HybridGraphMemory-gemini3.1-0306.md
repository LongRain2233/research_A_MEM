# Agent Memory 微创新课题指南

**生成时间**：2026-03-06 22:35:00
**生成模型**：gemini-3.1-pro-preview

---

## 🏷️ 课题名称：Semantic-Anchored Dynamic Evolution: Mitigating Memory Drift in Agentic Zettelkasten Networks

### 🔍 问题背景与研究动机（核心逻辑）
**① 当前缺陷**：现有的动态/演化式记忆系统（如 A-Mem）完全依赖无约束的 LLM 进行记忆节点的关联与演化更新。文献指出，这种不受控的演化容易导致“记忆表示漂移、语义失真或链接网络陷入混乱”（A-Mem 的 Limitation）。同时，《Semantic Anchoring》指出单纯依赖稠密嵌入会忽略深层语言结构（指代、转折），导致检索冲突。
**② 现有方案的缺口**：A-Mem 虽然实现了自主记忆组织，但其演化机制属于黑盒，缺乏显式的语义约束和失败溯源（ComoRAG 提出缺乏连贯的记忆探针会使得错误推理累积）。在低算力下（依赖大量请求轻量级 LLM API 时）极易产生幻觉雪崩。
**③ 因果链**：动态图记忆缺乏演化护栏（问题）→ 现有方案过度依赖 LLM 自由发挥导致漂移（缺口）→ 引入显式话语关系锚点与探针线索作为演化先验约束（我们的方案）。

### 🎯 切入点与 CCF C 类潜力
基于明确的现有 SOTA (A-Mem) 源码进行轻量级护栏设计，属于典型的“机制微调”。创新点逻辑严密，通过规则和轻量化符号控制了高昂的 LLM 调用成本，极大契合单人极低算力的研究现状。具备 CCF C 类长文保底及 B 类短文（Short Paper）的潜力。

### ⚙️ 核心方法/融合机制设计
主干采用论文 **A-Mem** 的“原子笔记+动态链接”数据结构。
1. **语义锚点注入**：在笔记构建阶段，不再仅生成上下文，而是利用轻量级 NLP 工具提取**话语关系标签（Discourse Relation Tags，如 Contrast, Elaboration）**，并借鉴 **ComoRAG** 的机制为笔记附带**历史失败/成功线索（Cue）**。
2. **受控演化路由**：在链接与演化阶段，打破 A-Mem 对所有近邻节点调用 LLM 的做法。加入“锚点路由”：仅当新旧记忆存在特定关联标签（如 Contrast 代表潜在事实冲突，且旧记忆的 Cue 标记为不稳定）时，才触发调用 LLM 的演化重写操作。
这极大地过滤了不必要的 LLM 调用，同时在发生重写前给模型施加了“此处发生了事实转折”的强制指令约束，锁定演化方向。

### 🧪 实验方案（算力受限 + GitHub 优先）
- **代码起点**：直接基于 **A-Mem** 的 GitHub 源码，核心修改其 `link_generation` 和 `memory_evolution` 模块。
- **实验环境**：单卡 3060 Ti 用于轻量级 Sentence-BERT 嵌入提取与简单句法关系工具的本地运行；推理引擎全部使用 OpenAI / DeepSeek API。
- **数据集**：LoCoMo（长对话 QA）和 DialSim。重点验证在相同准确率下，演化稳定性（语义连贯性）的提升，以及 **API 调用成本的大幅下降率**。

### 📚 严格文献溯源与融合逻辑
- **《A-Mem: Agentic Memory for LLM Agents》**(with_github)：贡献了**代码基础**与**原子记忆结构的动态演化主干**。(占比 33.3%)
- **《ComoRAG: A Cognitive-Inspired Memory-Organized RAG...》**(with_github)：贡献了**局部机制启发**（记忆探针线索 Cue），用于记录节点的历史状态避免重复演化。(占比 33.3%)
- **《Semantic Anchoring in Agentic Memory》**(without_github)：贡献了**创新问题发现与机制改进**，指出引入显式话语关系可作为记忆锚点，解决演化漂移痛点。(占比 33.3%)
*注：核心融合论文共 3 篇，其中 2 篇 (66.7%) 来自 with_github，满足结构主干要求。*

### 🚀 第一步行动指南
精读 A-Mem 中关于记忆演化（Memory Evolution）的具体 Prompt 设计。克隆 A-Mem 官方仓库，优先跑通 `memory_manager.py` 中的节点更新逻辑，并尝试在其中硬编码插入一个假的“Contrast”标签，观察其底层演化行为的变化。

---

## 🏷️ 课题名称：Intent-Guided Graph Propagation: Alleviating Noise Retrieval in Event-Centric Agent Memory

### 🔍 问题背景与研究动机（核心逻辑）
**① 当前缺陷**：在超长多主题对话中，基于图的细粒度记忆检索会引入大量噪声。《A Simple Yet Strong Baseline (EMem)》的局限性明确指出，在频繁切换无关主题时，其检索池会被大量语义相似但意图无关的节点污染，导致关键事件漏检。
**② 现有方案的缺口**：EMem 或其他图记忆系统（如 G-Memory）主要依赖局部的“论元实体提及”匹配，以及固定的图传播阻尼因子（PPR）来游走检索子图，缺乏对用户“全局高层任务意图（Task Intent）”的感知，导致激活的记忆子图盲目跨越了主题边界。
**③ 因果链**：图检索在多主题下面临噪声爆炸（问题）→ 现有游走机制缺乏宏观意图剪枝（缺口）→ 引入意图对齐层来限制和掩码 PPR 的游走边界（我们的方案）。

### 🎯 切入点与 CCF C 类潜力
图检索算法的轻量级创新，不涉及复杂的模型训练，仅需对图邻接矩阵或游走算法进行约束性修改，工程落地性极强。在多轮多主题长对话任务上（痛点明显）效果立竿见影，足以支撑 CCF C 类的发表。

### ⚙️ 核心方法/融合机制设计
主干采用 **EMem** 的“事件-论元异构图”（Session-EDU-Argument Graph）数据结构与 PPR 检索代码。
1. **意图-洞察抽象层**：借鉴 **G-Memory** 的层次化设计，在 EMem 扁平的 EDU 节点之上，每隔几轮抽取一个高层“Task Intent/Insight 节点”挂载于当前会话。
2. **意图路由的图传播（PPR Masking）**：融合《MemGuide》的“意图驱动选择”思想。当新查询到达时，先提取当前意图，并与历史意图节点进行余弦匹配。在执行 EMem 的图传播算法构建转移矩阵时，根据意图匹配度**动态调整 EDU 节点间的连通权重**。强行截断那些“意图完全不同”的跨主题节点的传播概率，实现子图的纯净裁剪。

### 🧪 实验方案（算力受限 + GitHub 优先）
- **代码起点**：基于 **EMem** 源码，修改其异构图图构建模块（增加 Intent 层）以及 `EMem-G` 的 Personalized PageRank 计算逻辑。
- **实验环境**：3060 Ti 足以支撑运行 NetworkX/DGL 等本地图算法与轻量级向量匹配。EDU 和 Intent抽取依赖轻量级 API 调用。
- **数据集**：LongMemEvalS 的多会话（Multi-Session）和开放域推理子集，通过消融实验重点展示加入了 Intent Mask 后噪声节点的过滤率。

### 📚 严格文献溯源与融合逻辑
- **《A Simple Yet Strong Baseline for Long-Term Conversational Memory...》**(with_github)：贡献了**核心代码基础**、**评测基准**与**事件中心图结构**。(占比 33.3%)
- **《G-Memory: Tracing Hierarchical Memory for Multi-Agent Systems》**(with_github)：贡献了**局部机制启发**，将扁平 EDU 抽象出上层意图节点。(占比 33.3%)
- **《MemGuide: Intent-Driven Memory Selection...》**(without_github)：贡献了**创新问题发现**（静态相似度引发连贯性中断）及**意图对齐剪枝的核心算法机制**。(占比 33.3%)
*注：核心融合论文共 3 篇，其中 2 篇 (66.7%) 来自 with_github，满足结构主干要求。*

### 🚀 第一步行动指南
精读 EMem 论文第 2.2 节的 PPR 检索数学公式。克隆 EMem 仓库，找到图传播权重（adjacency matrix）的初始化代码，尝试手动写死几个无关会话节点的权重为 0，验证图阻断对回答准确率的积极影响。

---

## 🏷️ 课题名称：Retrospective Temporal Invalidation: Lightweight Conflict Resolution in Temporal Agent Knowledge Graphs

### 🔍 问题背景与研究动机（核心逻辑）
**① 当前缺陷**：在动态交互中，现有的时序知识图谱记忆（如 ZEP）高度依赖前向的 LLM 处理——即每次写入新事实，都要调用 LLM 与全量历史事实进行对比以设定失效时间（$t_{invalid}$）。这不仅导致 O(N) 的极高计算延迟（ZEP 承认的可扩展性缺陷），还容易因 LLM 的对比幻觉误删有效记忆。
**② 现有方案的缺口**：这种“写入时立刻全局消歧”的前向策略在边缘端算力下根本不现实，并且完全忽略了对话系统可以在“后续的实际问答交互”中获取免费的验证信号的优势。
**③ 因果链**：状态更新开销巨大且易发生误删（问题）→ 现有方案采用僵化的前向即时冲突检测（缺口）→ 引入延迟失效机制，根据真实交互中的失败反馈和引用奖励动态修剪图谱（我们的方案）。

### 🎯 切入点与 CCF C 类潜力
将庞大的计算压力从“记忆写入阶段”平移转移至“异步使用/挂起阶段”，成倍降低系统延迟和 API 成本。这种从 System 角度对算法流程进行的优化极具系统级 track 会议的吸引力，非常适合算力极低的独立研究者突破，上限可达 CCF B 级。

### ⚙️ 核心方法/融合机制设计
主干采用 **ZEP** 论文的三层时序知识图谱（Temporal KG）代码结构。
1. **状态挂起与延迟评估**：改变 ZEP 的底层写入逻辑。写入新事件时，不再立即调用昂贵的 LLM 事实对比模块，而是采用低成本的“附加（Append-only）”操作，将新节点状态标记为“待定（Pending）”。
2. **后顾性失效修剪（Retrospective Invalidation）**：融合《ComoRAG》的失败驱动激活概念与《In Prospect and Retrospect》的引用反馈。仅当智能体在回答问题检索时，同时提取到了相互冲突的新旧节点（基于时间线重叠发现），此时才激活冲突处理：若 LLM 最终生成答案时**明确引用了新节点而废弃了旧节点**，系统捕捉这一免费的“后顾性引用（Retrospective Citation）”信号，反向将旧节点的 $t_{invalid}$ 闭合，完成图谱衰减。

### 🧪 实验方案（算力受限 + GitHub 优先）
- **代码起点**：基于 **ZEP (Graphiti)** 源码引擎。大规模接管重写其图谱更新流水线与事实失效（Fact Invalidation）路由。
- **实验环境**：纯 API 引擎模式，本地 3060 Ti 用于部署 Graphiti 图数据库基座及小模型向量缓存。
- **数据集**：LongMemEval 的时序推理与知识更新（Knowledge Update）子集，重点对比新机制与原版 ZEP 的检索准确率，以及**写入延迟（API 耗时）的绝对下降量**。

### 📚 严格文献溯源与融合逻辑
- **《ZEP: A TEMPORAL KNOWLEDGE GRAPH ARCHITECTURE...》**(with_github)：贡献了**代码基础主干**、**三层图谱引擎**与**失效边定义**。(占比 33.3%)
- **《ComoRAG: A Cognitive-Inspired Memory-Organized RAG...》**(with_github)：贡献了**局部机制启发**，将全局遍历改为基于任务成败的按需触发循环。(占比 33.3%)
- **《In Prospect and Retrospect: Reflective Memory Management...》**(without_github)：贡献了**问题发现及机制补强**，即利用后顾性引用（Retrospective Reflection）反馈进行无监督修剪，化解前向计算灾难。(占比 33.3%)
*注：核心融合论文共 3 篇，其中 2 篇 (66.7%) 来自 with_github，满足结构主干要求。*

### 🚀 第一步行动指南
精读 ZEP 论文关于“双时间模型与矛盾消除”机制的定义。去 GitHub 克隆 ZEP 官方底层库（Graphiti），定位到添加新实体时触发计算冲突（Conflict Detection）的 API 调用位置，将其注释并改为挂起（Pending），测量写入速度的倍数级跃升。